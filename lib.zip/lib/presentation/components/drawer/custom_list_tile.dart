import 'package:dago_valley_explore/app/extensions/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomListTile extends StatelessWidget {
  final bool isCollapsed;
  final bool isActive;
  final IconData icon;
  final String svgIcon;
  final String title;
  final IconData? doHaveMoreOptions;
  final int infoCount;

  const CustomListTile({
    Key? key,
    required this.isCollapsed,
    required this.isActive,
    required this.icon,
    required this.svgIcon,
    required this.title,
    this.doHaveMoreOptions,
    required this.infoCount,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 500),
        width: isCollapsed ? 300 : 80,
        margin: EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: HexColor("282924"),
          border: isActive
              ? Border.all(width: 4, color: HexColor("5C5C5A"))
              : Border.all(width: 4, color: Colors.transparent),
          borderRadius: BorderRadius.circular(8),
        ),
        height: 70,
        child: Row(
          children: [
            Expanded(
              child: Center(
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      padding: EdgeInsets.all(18),
                      // decoration: BoxDecoration(
                      //   color: HexColor("282924"),
                      //   borderRadius: BorderRadius.circular(8),
                      // ),
                      child: SvgPicture.asset(svgIcon),
                    ),
                    if (infoCount > 0)
                      Positioned(
                        right: -2,
                        top: -2,
                        child: Container(
                          height: 12,
                          width: 12,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.transparent,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (isCollapsed) const SizedBox(width: 10),
            if (isCollapsed)
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Expanded(
                      flex: 4,
                      child: Text(
                        title,
                        style: const TextStyle(color: Colors.white),
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                      ),
                    ),
                    if (infoCount > 0)
                      Expanded(
                        flex: 2,
                        child: Container(
                          margin: const EdgeInsets.only(left: 10),
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.purple[200],
                          ),
                          child: Center(
                            child: Text(
                              infoCount.toString(),
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            if (isCollapsed) const Spacer(),
            if (isCollapsed)
              Expanded(
                flex: 1,
                child: doHaveMoreOptions != null
                    ? IconButton(
                        icon: Icon(
                          doHaveMoreOptions,
                          color: Colors.white,
                          size: 12,
                        ),
                        onPressed: () {},
                      )
                    : const Center(),
              ),
          ],
        ),
      ),
    );
  }
}
