import 'package:dago_valley_explore/app/extensions/color.dart';
import 'package:dago_valley_explore/app/types/tab_type.dart';
import 'package:dago_valley_explore/presentation/components/drawer/bottom_user_info.dart';
import 'package:dago_valley_explore/presentation/components/drawer/custom_list_tile.dart';
import 'package:dago_valley_explore/presentation/components/drawer/header.dart';
import 'package:flutter/material.dart';

class CustomDrawer extends StatefulWidget {
  const CustomDrawer({Key? key}) : super(key: key);

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  bool _isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedContainer(
        curve: Curves.easeInOutCubic,
        duration: const Duration(milliseconds: 500),
        width: _isCollapsed ? 300 : 85,
        margin: const EdgeInsets.only(bottom: 10, top: 10, left: 10),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          color: HexColor("1C1C19"),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 10),
              CustomDrawerHeader(isColapsed: _isCollapsed),
              // const Divider(color: Colors.grey),
              Spacer(),
              ...TabType.values
                  .where((e) => e != TabType.bookingonlinepage)
                  .map(
                    (e) => CustomListTile(
                      isActive: false,
                      isCollapsed: _isCollapsed,
                      icon: Icons.home_max,
                      svgIcon: e.svgIcon,
                      title: 'Home',
                      infoCount: 0,
                    ),
                  )
                  .toList(),
              Spacer(),
              // CustomListTile(
              //   isActive: false,
              //   isCollapsed: _isCollapsed,
              //   icon: Icons.home_max,
              //   svgIcon: "assets/menu/home_icon.svg",
              //   title: 'Home',
              //   infoCount: 0,
              // ),
              // CustomListTile(
              //   isActive: false,
              //   isCollapsed: _isCollapsed,
              //   icon: Icons.calendar_today,
              //   svgIcon: "assets/menu/siteplan_icon.svg",
              //   title: 'Calender',
              //   infoCount: 0,
              // ),
              // CustomListTile(
              //   isActive: false,
              //   isCollapsed: _isCollapsed,
              //   icon: Icons.pin_drop,
              //   svgIcon: "assets/menu/product_icon.svg",
              //   title: 'Destinations',
              //   infoCount: 0,
              //   doHaveMoreOptions: Icons.arrow_forward_ios,
              // ),
              // CustomListTile(
              //   isActive: false,
              //   isCollapsed: _isCollapsed,
              //   icon: Icons.message_rounded,
              //   svgIcon: "assets/menu/calculator_icon.svg",
              //   title: 'Messages',
              //   infoCount: 8,
              // ),
              // CustomListTile(
              //   isActive: false,
              //   isCollapsed: _isCollapsed,
              //   icon: Icons.cloud,
              //   svgIcon: "assets/menu/folder_icon.svg",
              //   title: 'Weather',
              //   infoCount: 0,
              //   doHaveMoreOptions: Icons.arrow_forward_ios,
              // ),
              // // const Divider(color: Colors.grey),
              // const Spacer(),
              CustomListTile(
                isActive: false,
                isCollapsed: _isCollapsed,
                icon: Icons.settings,
                svgIcon: "assets/menu/hotline_icon.svg",
                title: 'Settings',
                infoCount: 0,
              ),
              const SizedBox(height: 10),
              // BottomUserInfo(isCollapsed: _isCollapsed),
              // Align(
              //   alignment: _isCollapsed
              //       ? Alignment.bottomRight
              //       : Alignment.bottomCenter,
              //   child: IconButton(
              //     splashColor: Colors.transparent,
              //     icon: Icon(
              //       _isCollapsed
              //           ? Icons.arrow_back_ios
              //           : Icons.arrow_forward_ios,
              //       color: Colors.white,
              //       size: 16,
              //     ),
              //     onPressed: () {
              //       setState(() {
              //         _isCollapsed = !_isCollapsed;
              //       });
              //     },
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
