abstract class NoParamUseCase<Type> {
  Future<Type> execute();
}
