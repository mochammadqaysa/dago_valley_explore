class APIEndpoint {
  static String get newsapi => "https://newsapi.org/v2";
}
